/**
 * 
 */
/**
 * @author broke
 *
 */
module HospitalPatientManagementSystem {
	requires java.desktop;
}