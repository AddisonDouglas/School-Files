/**
 * 
 */
package cs141.group;

import java.awt.ComponentOrientation;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

/**
 * Name:Addison Douglas and Braeden Farry
 * Section: 1
 * Program Name: Caller
 * Description: creates menuframe
 *
 */
public class Caller {
	

	/**
	 * @param args
	 */

	public static void main(String[] args) {
				//Creation of frame
				MenuFrame frame = new MenuFrame();//creating instance of frame name menu
		        

		        
	

		    
		}
}

		
		

	


