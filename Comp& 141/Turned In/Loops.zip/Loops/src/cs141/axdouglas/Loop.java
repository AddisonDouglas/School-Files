/**
 * 
 */
package cs141.axdouglas;

import java.util.Scanner;

/**
 * @author axdouglas
 *
 */
public class Loop {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner userInput = new Scanner(System.in);
		int postiverIntergers = 0;
		int total = 0;
		double average = 0;
		System.out.println("Enter 10 postive numbers or a negative to stop");
		for(int i = 1; i < 11; i++) 
		{
			System.out.print("num" + i +":");
			int userInt = userInput.nextInt();
			if(userInt < 0 ){
				System.out.println("you quit");
				break;
			}
			else{
				postiverIntergers++;
				total += userInt;
			}
			
		}
		average = (double) total/ (double)postiverIntergers;
		System.out.format("Number of positive Intergers: %d %nTotal: %d %nAvergae: %.02f%n", postiverIntergers, total,average );
		userInput.close();
	}

}
