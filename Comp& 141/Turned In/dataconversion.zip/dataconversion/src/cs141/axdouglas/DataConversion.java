/**
 * 
 */
package cs141.axdouglas;

/**
 * @author broke
 *
 */
public class DataConversion {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] intArray = new int[10]; // create array with length of 10
		for(int i = 0; i < intArray.length; i++) { //set all values to 0
			intArray[i] = 0;
		}
		for(int i = 1; i < intArray.length+1; i++) { //set values to multiples of 10
			intArray[i-1] = i * 10;
		}
		for(int i = 0; i < intArray.length; i++) { //print out array
			System.out.println(intArray[i]);
		}
		//ACTIVTY 2
		//--------------------------------------------------
		System.out.print("----------------------------------------------");
		String[] names = { "Scooby", "Shaggy", "Velma", "Fred", "Daphne" };
		int[][] grades = new int[][] {
			  { 10, 9, 10, 9, 8, 6, 8, 5, 9, 10 },
			      { 8, 9, 10, 9, 8, 6, 8, 5, 9, 10 },
			      { 9, 9, 9, 9, 8, 10, 10, 9, 9, 8 },
			      { 10, 5, 6, 5, 6, 9, 6, 7, 8, 8 },
			      { 10, 10, 10, 10, 10, 10, 10, 10, 10, 10 }
			      };
		int rows = grades.length;  
		int cols = grades[0].length;  
		for(int y = 0; y < cols; y++) { //adds up one entire column(homework assigment) putting that in sum
			double sum = 0;
			for(int x = 0; x < rows; x++) {
				sum = sum + grades[x][y];
			}
			System.out.println();
			System.out.printf("Homework %d's average: %.02f", y+1 , sum/(double) rows); //print the average by dividng sum by rows 
		}
		
	}

}
