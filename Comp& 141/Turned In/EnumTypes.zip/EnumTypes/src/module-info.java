/**
 * 
 */
/**
 * @author broke
 *
 */
module EnumTypes {
}