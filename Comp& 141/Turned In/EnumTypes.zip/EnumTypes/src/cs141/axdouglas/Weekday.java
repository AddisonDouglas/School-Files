/**
 * 
 */
package cs141.axdouglas;

/**
 * @author axdouglas
 *
 */
/**
 * Name:Addison Douglas
 * Section: 1
 * Program Name: Weekday
 * Description: This enum has constants for the days of the week, and two methods, is WeekDay, and isHoliday, isHoliday
 * returns the opposite of is WeekDay
 *
 */
public enum Weekday {
	SUNDAY,MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY, SATURDAY;
	boolean isWeekDay() {
		return true;
	}
	boolean isHoliday() {
		return !isWeekDay();
	}

}
