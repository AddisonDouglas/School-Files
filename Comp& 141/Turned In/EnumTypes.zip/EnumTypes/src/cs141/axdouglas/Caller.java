/**
 * 
 */
package cs141.axdouglas;

/**
 * @author broke
 *
 */
public class Caller {

	/**
	 * @author axdouglas
	 *
	 */
	/**
	 * Name:Addison Douglas
	 * Section: 2
	 * Program Name: Caller
	 * Description:uses a for each loop to go through the days of the week and pass them into the method testDay
	 * it then uses an if statment to check if the day is sunday or saturday and prints out "Stay home and play with your cat"
	 * otherwise it is a weekday day and prints "Go to Work"
	 *
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(Weekday day: Weekday.values()) {
			testDay(day);
		}
	}
	public static void testDay(Weekday day) {
		if(day == Weekday.SUNDAY || day == Weekday.SATURDAY) {
			System.out.println("Stay home and play with your cat");
		}
		else {
			System.out.println("Go To work");
		}

	}

}
