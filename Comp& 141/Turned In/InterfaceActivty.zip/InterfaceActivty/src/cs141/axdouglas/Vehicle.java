package cs141.axdouglas;
/**
 * @author axdouglas
 *
 */
/**
 * Name:Addison Douglas
 * Section: 2
 * Program Name: Vehicle
 * Description: this is a class that implements Engine, defiens the two methods and has two varibles int gear and int speed
 */


public class Vehicle implements Engine {
	public int gear;
	public int speed;

	@Override
	public void changeGear(int a) {
		// TODO Auto-generated method stub
		this.gear = a;
		
	}

	@Override
	public void speedUp(int a) {
		// TODO Auto-generated method stub
		this.speed = a;
	}
	public String toString() {
		return "Vehicle [speed=" + speed +", gear=" + gear + "]"   ;
	}

}
