package cs141.axdouglas;
/**
 * @author axdouglas
 *
 */
/**
 * Name:Addison Douglas
 * Section: 1
 * Program Name: Engine
 * Description: This is an interface that defiens two methods, changeGear and SpeedUp both accpeting an int
 */
interface Engine {
	void changeGear(int a);
	void speedUp(int a);
	

}
