/**
 * 
 */
package cs141.axdouglas;

/**
 * @author axdouglas
 *
 */
/**
 * Name:Addison Douglas
 * Section: 3
 * Program Name: Caller
 * Description: Creats a vehcicle object, sets gear to 3 and speed to 70 and prints it out
 *
 */
public class Caller {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vehicle objv = new Vehicle();
		objv.changeGear(3);
		objv.speedUp(70);
		System.out.println(objv);

	}

}
