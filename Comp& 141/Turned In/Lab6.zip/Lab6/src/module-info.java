/**
 * 
 */
/**
 * @author broke
 *
 */
module Lab6 {
}