/**
 * 
 */
package cs141.axdouglas;

import java.util.Scanner;

/**
 * @author axdouglas
 *
 */
/**
 * Name:Addison Douglas
 * Section: 2
 * Program Name: ClockDemo
 * Description: This class interacts with the clock class showing the methods avaible.
 *
 */
public class ClockDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner userInput = new Scanner(System.in);
		System.out.println("Seconds since midnight?");
		int secondsSinceMidnight = userInput.nextInt();
		Clock firstClock = new Clock(secondsSinceMidnight);
		firstClock.toPrint();
		for(int i = 0; i < 10; i++) {
			firstClock.tick();
			firstClock.toPrint();
		}
		int hour = 0;
		int minutes = 0;
		int seconds = 0;
		boolean bool = true;
		boolean bool2 = true;
		boolean bool3 = true;

		while(bool) {
			System.out.println("Hour?");
			hour = userInput.nextInt();
			if(hour>=24) {
				bool = true;
			}
			else {
				bool = false;
			}
		}
		while(bool2) {
			System.out.println("Minutes?");
			minutes = userInput.nextInt();
			if(minutes>=60) {
				bool2 = true;
			}
			else {
				bool2 = false;
			}
		}
		
		while(bool3) {
			System.out.println("seconds?");
			seconds = userInput.nextInt();
			if(seconds>=60) {
				bool3 = true;
			}
			else {
				bool3 = false;
			}
		}
		Clock secondClock = new Clock(hour, minutes, seconds);
		for(int i = 0; i < 10; i++) {
			secondClock.tick();
			secondClock.toPrint();
	}
		firstClock.addClock(secondClock);
		firstClock.toPrint();
		secondClock.toPrint();
		Clock thirdClock = firstClock.subtractClock(secondClock);
		thirdClock.toPrint();
		
		

	}


}
