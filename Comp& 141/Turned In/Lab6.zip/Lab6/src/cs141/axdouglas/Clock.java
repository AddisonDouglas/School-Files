/**
 * 
 */
package cs141.axdouglas;

/**
 * @author axdouglas
 *
 */
/**
 * Name:Addison Douglas
 * Section: 1
 * Program Name: Clock
 * Description: The clock class has three contrsucotrs for an object to be created from, blank sets it to twelve, or the hour minute and second
 * can be provided, or the seconds since midnight can be provided which will then be converted to hours minutes and seconds. there are setters
 * and getters for the three varibles, hour minutes and seconds. There is a set clock which is the same as the third construcot, taking 
 * in seconds since midnight, there is addclock which adds a clock objects time to the current one, and a subtract which returns the diffreance
 * of two clock objects in a clock object.
 *
 */
public class Clock {
	private int hour ;
	private int minutes;
	private int seconds;
	
	public Clock() {
		this.hour = 12;
		this.minutes = 0;
		this.seconds = 0;
	}
	public Clock(int hour, int minutes, int seconds) {
		this.hour = hour;
		this.minutes = minutes;
		this.seconds = seconds;
	}
	public Clock(int secondsSinceMidnight) {
		this.hour = secondsSinceMidnight / 3600;
		secondsSinceMidnight = secondsSinceMidnight % 3600;
		this.minutes = secondsSinceMidnight / 60;
		this.seconds = secondsSinceMidnight % 60;
		if(seconds >= 60) { 
			minutes += seconds/60;
			seconds = seconds % 60;
		}
		if(minutes >= 60) {
			hour += minutes /60;
			minutes = minutes % 60;
		}
		if(hour >= 24) {
			hour = hour % 24;
		}
		
		
	}
	public void setClock(int secondsSinceMidnight) {
		this.hour = secondsSinceMidnight / 3600;
		secondsSinceMidnight = secondsSinceMidnight % 3600;
		this.minutes = secondsSinceMidnight / 60;
		this.seconds = secondsSinceMidnight % 60;
		if(seconds >= 60) { 
			minutes += seconds/60;
			seconds = seconds % 60;
		}
		if(minutes >= 60) {
			hour += minutes /60;
			minutes = minutes % 60;
		}
		if(hour >= 24) {
			hour = hour % 24;
		}
	}
	public void toPrint() {
		System.out.printf("%02d:%02d:%02d%n", hour, minutes, seconds);
	}
	public void addClock(Clock clock) {
		this.hour +=  clock.getHour();
		this.minutes += clock.getMinutes();
		this.seconds += clock.getSeconds();
		if(seconds >= 60) { 
			minutes += seconds/60;
			seconds = seconds % 60;
		}
		if(minutes >= 60) {
			hour += minutes /60;
			minutes = minutes % 60;
		}
		if(hour >= 24) {
			hour = hour % 24;
		}
	}
	public void tick() {
		seconds += 1;
		if (seconds == 60) {
			seconds = 0;
			minutes += 1;
		}
		if(minutes == 60) {
			minutes = 0;
			hour +=1 ;
			
		}
		if(hour == 24) {
			hour = 0;
		}
	}
	public void tickDown() {
		seconds -= 1;
		if(seconds == -1) {
			minutes -= 1;
			seconds = 59;
		}
		if(minutes == -1) {
			hour -= 1;
			minutes = 59;
		}
		if(hour == -1) {
			hour = 0;
		}
	}
	/**
	 * @return the hour
	 */
	public int getHour() {
		return hour;
	}
	/**
	 * @param hour the hour to set
	 */
	public void setHour(int hour) {
		this.hour = hour;
	}
	/**
	 * @return the minutes
	 */
	public int getMinutes() {
		return minutes;
	}
	/**
	 * @param minutes the minutes to set
	 */
	public void setMinutes(int minutes) {
		this.minutes = minutes;
	}
	/**
	 * @return the seconds
	 */
	public int getSeconds() {
		return seconds;
	}
	/**
	 * @param seconds the seconds to set
	 */
	public void setSeconds(int seconds) {
		this.seconds = seconds;
	}
	public Clock subtractClock(Clock clock) {
		// TODO Auto-generated method stub
		Clock  returnClock = new Clock(Math.abs(this.hour - clock.getHour()), Math.abs( this.minutes - clock.getMinutes()), Math.abs( this.seconds - clock.getSeconds()));
		return returnClock;
	}


}
