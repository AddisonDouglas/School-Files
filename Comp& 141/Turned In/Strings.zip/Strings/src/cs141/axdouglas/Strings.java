/**
 * 
 */
package cs141.axdouglas;

import java.util.Scanner;

/**
 * @author axdouglas
 *
 */
public class Strings {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String input1;  //declare strings i'll need
		String input2;
		String input1ConcatInput2;
		String input3;
		Scanner input = new Scanner(System.in); //create scanner
		System.out.print("Input First String:");
		input1 = input.next(); //get first input, store in input1
		System.out.print("Input Second String:");
		input2 = input.next();//get second input, store in input2
		System.out.println("-------------------------");
		System.out.println("Concatenate the two strings into one:");
		input1ConcatInput2 = input1 + input2; //concat input1 and input2
		System.out.println(input1ConcatInput2);
		System.out.println("-------------------------");
		System.out.println("Check if the two strings are equal:");
		if(input1.equalsIgnoreCase(input2)) { //test if equal
			System.out.println(input1 + " and " + input2+ " are equal");
		}
		else {
			System.out.println(input1 + " and " + input2+ " are not equal");

		}
		System.out.println("-------------------------");
		System.out.println("Convert the strings to uppercase:");
		System.out.println(input1.toUpperCase());
		System.out.println(input2.toUpperCase());
		System.out.println("-------------------------");
		System.out.println("Convert d to e in the two strings");
		System.out.println(input1.replace('d', 'e'));
		System.out.println(input2.replace('d', 'e'));
		System.out.println("-------------------------");
		System.out.println("Input a string:");
		input3 = input.next(); //get third input
		System.out.println("Check if either of the first two inputs end with the third");
		int g = input3.length();
		String temp = input1.substring((input1.length())-g, input1.length());  //creates substring that start at then end minus the length of input3, to the end of input1		
		if(temp.equals(input3)) {
			System.out.println(input1 + " ends with " + input3);
			
			
		}
		else {
			System.out.println(input1 + " does not end with " + input3);

		}
		String temp2 = input2.substring((input1.length())-g, input1.length());  //creates substring that start at then end minus the length of input3, to the end of input1		
		if(temp2.equals(input3)) {
			System.out.println(input2 + " ends with " + input3);
			
			
		}
		else {
			System.out.println(input2 + " does not end with " + input3);

		}
		
		
		}
	
		
		
		

	
}
