/**
 * 
 */
/**
 * @author broke
 *
 */
module Strings {
}