/**
 * 
 */
/**
 * @author broke
 *
 */
module HelloWorld {
}