/**
 * 
 */
package cs141.axdouglas;
/**
 * Name : Addison Douglas
 * Section: A
 * Program Name: Birthday Wizard
 * 
 * Description: This program takes two integer from the user, one being their birth year
 * and one being an age. It then calculates what year they would be that age in by adding age and 
 * birth year together. Then that new calculated year is printed to the user.
 * 
 */
import java.util.Scanner;

/**
 * @author axdouglas
 *
 */
public class BirthdayWizard {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("My name is Addison Dougas");
		System.out.println("Program 1: Birthday Wizard");
		System.out.println("-----------------------");
		Scanner userInput = new Scanner(System.in);
		System.out.println("What year were you born?");
		int yearOfBirth = userInput.nextInt();
		System.out.println("Choose an age in years?");
		int age = userInput.nextInt();
		int newYear = yearOfBirth + age;
		System.out.format("You will turn %d in the year %d",age, newYear);
		userInput.close();
		

	}

}
