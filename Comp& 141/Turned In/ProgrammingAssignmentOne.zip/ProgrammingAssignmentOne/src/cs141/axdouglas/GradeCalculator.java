/**
 * 
 */
package cs141.axdouglas;
/**
 * Name : Addison Douglas
 * Section: B
 * Program Name: Grade Calculator
 * 
 * Description: This program uses scanner to get 5 grades from the user, the grades being
 * 0-100. It then adds those all up and divides by 5 to get the average. This average is then
 * sent through an if statement to decide what the letter grade would be. The average
 * and the letter grade is then output to the user.
 */

import java.util.Scanner;

/**
 * @author axdouglas
 *
 */
public class GradeCalculator {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("My name is Addison Dougas");
		System.out.println("Program 1: Grade Calcalculator");
		System.out.println("-----------------------");
		Scanner userInput = new Scanner(System.in);
		System.out.println("Enter five grades(0-100)");
		double grade1 = userInput.nextInt();
		double grade2 = userInput.nextInt();
		double grade3 = userInput.nextInt();
		double grade4 = userInput.nextInt();
		double grade5 = userInput.nextInt();
		double gradeAverage = (grade1 + grade2 + grade3 + grade4 + grade5) / 5.0;
		char letterGrade;
		if(gradeAverage<=100 && gradeAverage >= 90) {
			letterGrade = 'A';
		}
		else if(gradeAverage<=80 && gradeAverage >= 89) {
			letterGrade = 'B';
		}
		else if(gradeAverage<=70 && gradeAverage >= 79) {
			letterGrade = 'C';
		}
		else if(gradeAverage<=60 && gradeAverage >= 69) {
			letterGrade = 'D';
		}
		else {
			letterGrade = 'F';
		}
		System.out.format("The avrage of the 5 grades is %.2f %n", gradeAverage);
		System.out.format("The letter grade is: %c%n", letterGrade);

	}

}
