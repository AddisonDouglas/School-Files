package cs141.axdouglas;
/**
 * @author axdouglas
 *
 */
/**
 * Name:Addison Douglas
 * Section: 1
 * Program Name: Array and functions
 * Description: takes an array, and uses a for loop to go through each element, doing three things, for the average 
 * it simple adds the element to total and late divides by the length, for the max it compares what the current max is,
 * starting with element zero, to the current element, and if it is more it changes the value of max, it does the same thing for min but 
 * instead changes it if it is less than min
 *
 */

public class ArraysAndFunctions {
	
	/**
	 * @param args
	 */
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] intArray = new int[]{20, 10, -14, 9, 6};
		double total = 0;
		int max = intArray[0];
		int min = intArray[0];
		System.out.println("The contents of the array: ");
		for(int i = 0; i < intArray.length; i++) {
			System.out.print(intArray[i] + " ");
		}
		System.out.println("\n-------------------");
		for(int i = 0; i < intArray.length; i++) {
			if(intArray[i] < min) {
				min = intArray[i];
			}
			if(intArray[i] > max) {
				max = intArray[i];
			}

			total += intArray[i];
		}
		System.out.println("The max is: "+ max);
		System.out.println("The min is: " + min);
		System.out.println("The average is: " + total/intArray.length);
		
	}

}
