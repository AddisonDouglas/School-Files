/**
 * 
 */
package cs141.axdouglas;

/**
 * @author axdouglas
 *
 */
/**
 * Name:Addison Douglas
 * Section: 2
 * Program Name: LongestWord
 * Description:First a 2d string area called dictionary is made and filled with random words, then two methods are called
 * a printArray method, which accepts dictionary as a input and then prints out the array. findLongestWordAndOccurrences, has two for loops
 * at first it goes through the array and finds the longest word using .length(), it then goes through again and finds how many times
 * the word occurs.
 *
 */
public class LongestWord {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[][] dictionary = {
				{"cat", "Comedy", "Circulate"}, 
				{"Mail", "move", "Dog" },
				{"Tract", "fool", "agile"}, 
				{"Circulate", "move", "cat" },
				{"Forge", "seed", "promise"},
				{"monk", "move", "Circulate"},
				{"Spontaneous", "Spontaneous", "seed"},
				{"pin", "tree", "Spontaneous"},
				{"Spontaneous", "Spontaneous"}
								};
		printArray(dictionary);
		findLongestWordAndOccurrences(dictionary);

	}
	public static void findLongestWordAndOccurrences(String[][] dictionary) {
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		String longestWord = dictionary[0][0];
		int count = 0;
		for(int i = 0; i < dictionary.length; i++) {
			for(int j = 0; j < dictionary[i].length; j++) {
				if(dictionary[i][j].length() > longestWord.length()) {
					longestWord = dictionary[i][j];
					
				}
			}
		}
		for(int i = 0; i < dictionary.length; i++) {
			for(int j = 0; j < dictionary[i].length; j++) {
				if(dictionary[i][j].equalsIgnoreCase(longestWord)) {
					count++;
					
				}
			}
		}
		System.out.println("The longest word is: " + longestWord);
		System.out.printf("It occurs %d times", count);
	}
	public static void printArray(String[][] dictionary) {
		System.out.println("\t    Contents of dictionary");
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		for(int i = 0; i < dictionary.length; i++) {
			for(int j = 0; j < dictionary[i].length; j++) {
				System.out.printf("%15s", dictionary[i][j]);
				//System.out.print(dictionary[i][j] + " ");
			}
			System.out.println();
		}
	}
	

}
