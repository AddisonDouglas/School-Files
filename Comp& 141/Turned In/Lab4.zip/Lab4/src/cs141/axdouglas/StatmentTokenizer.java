/**
 * 
 */
package cs141.axdouglas;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/**
 * @author axdouglas
 * /**
 * Name:Addison Douglas
 * Section: 3
 * Program Name: StatmentTokenizer
 * Description: This program first takes input from the user in the form of a sentence, then it use .split to create an array of 
 * of that input, the amount of words is just the length of the area. to get the unique words i used a nested for loop
 * that checks the element with all element behind it, and if it is them same it breaks out and sets a boolean variable to true
 * there is then a if statement that only happens if the variable is false which adds the element to a new area.
 * For the occurrecnes i used another nested for loop going back through the orginal array and comparing it to the new one with
 * the unique words, adding up all of the occurnces adn storing it in a int array
 *
 */

public class StatmentTokenizer {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner userInput = new Scanner(System.in);
		System.out.println("Enter a sentance: ");
		String sentance = userInput.nextLine();
		String [] sentanceArray = sentance.split(" ");
		String [] uniqueArray = new String[sentanceArray.length];
		
		int index = 0;
		for(int i = 0; i < sentanceArray.length; i++) {
			boolean test = false;
			for(int j = 0; j < i; j++) {
				if(sentanceArray[i].equals(sentanceArray[j])) {
					test = true;
					break;
				}
				
			}
			if(!test) {
				uniqueArray[index] = sentanceArray[i];
				index++;
			}
		}
		int [] occurrences = new int[index];
		for(int i = 0; i < index; i++) {
			int count = 0;
			for(int j = 0; j < sentanceArray.length; j++) {
				if(uniqueArray[i].equals(sentanceArray[j])) {
					count++;
				}
			}
			occurrences[i] = count;
		}
		System.out.printf("There are %d words in your sentance %n", sentanceArray.length);
		System.out.printf("There are %d unique words in your sentance%n", index);
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.printf("%-15s %-15s%n", "Words", "Occurences");
		System.out.printf("%-15s %-15s%n", "~~~~~", "~~~~~");
		for(int i = 0; i < index; i++) {
			System.out.printf("%-15s%-15s%n ", uniqueArray[i], occurrences[i]);
		}
		
		}
	}
		
		
		

	


