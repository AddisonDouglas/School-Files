/**
 * 
 */
/**
 * @author broke
 *
 */
module Lab4 {
}