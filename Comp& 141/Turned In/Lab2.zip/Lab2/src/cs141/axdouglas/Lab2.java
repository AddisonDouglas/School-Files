/**
 * 
 */
package cs141.axdouglas;

import java.util.Scanner;

/**
 * @author axdouglas
 *
 */
public class Lab2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner userInput = new Scanner(System.in); //scanner
		System.out.println("What is the price per square inch?");
		double pricePerSquareInch = userInput.nextDouble();
		System.out.println("What is the tax rate?(use floating point number)");
		double taxRate = userInput.nextDouble();
		taxRate = taxRate/100;
		double smallSquareInches = Math.pow(5, 2) * Math.PI;
		double costOfSmall = (smallSquareInches * pricePerSquareInch) * (1+ taxRate);
		double mediumSquareInches = Math.pow(6, 2) * Math.PI;
		double costOfMedium = (mediumSquareInches * pricePerSquareInch) * (1+ taxRate);
		double largeSquareInches = Math.pow(7, 2) * Math.PI;
		double costOfLarge = (largeSquareInches * pricePerSquareInch) * (1+ taxRate);
		System.out.format("Price of the 10 inch pizza is %.2f %n" , costOfSmall);
		System.out.format("Price of the 12 inch pizza is %.2f %n" , costOfMedium);
		System.out.format("Price of the 14 inch pizza is %.2f %n" , costOfLarge);
		userInput.close();

	}

}
