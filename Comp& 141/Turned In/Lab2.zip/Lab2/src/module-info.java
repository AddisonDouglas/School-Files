/**
 * 
 */
/**
 * @author broke
 *
 */
module Lab2 {
}