/**
 * 
 */
package cs141.axdouglas;

/**
 * @author axdouglas
 *
 */
/**
 * Name:Addison Douglas
 * Section: 3
 * Program Name: Caller
 * Description: creates a HR obj with John and 1 in the constructor, then calls commonEMPDetails to print
 * out the name and id, then calls confidentialDetails and passes in 6320.56 and "good" for salary and performance
 * which is then printed out.
 *
 */
public class Caller {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HR hr = new HR("John", 1);
		hr.commonEMPDetails();
		hr.confidentialDetails(6320.56, "good");

		

	}

}
