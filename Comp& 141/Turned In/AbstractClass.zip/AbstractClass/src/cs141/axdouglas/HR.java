package cs141.axdouglas;

/**
 * @author axdouglas
 *
 */
/**
 * Name:Addison Douglas
 * Section: 2
 * Program Name: HR
 * Description: HR extends EmployeeDetails and implments the abstract methods from it
 *
 */

public class HR extends EmployeeDetails{
	public String name;
	public int id;
	private double salary;
	private String performance;
	
	public HR(String name, int id) {
		super(name, id);
	}

	@Override
	public void confidentialDetails(double salary, String performance) {
		// TODO Auto-generated method stub
		this.salary = salary;
		this.performance = performance;
		System.out.println("Salary: " + this.salary);
		System.out.print("Performance: " + this.performance);
		
	}
	
	

}
