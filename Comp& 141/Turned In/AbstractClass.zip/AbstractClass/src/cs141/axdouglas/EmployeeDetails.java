/**
 * 
 */
package cs141.axdouglas;

/**
 * @author axdouglas
 *
 */
/**
 * Name:Addison Douglas
 * Section: 1
 * Program Name: EmployeeDetails
 * Description: EmployeeDetails is a abstract class that defines confidentialDetails but does not implment, and creats
 * a method commonEMPDetails that prints name and id;
 *
 */
public abstract class EmployeeDetails {
	public String name;
	public int id;
	public EmployeeDetails(String name, int id) {
		this.name = name;
		this.id = id;
	}
	public void commonEMPDetails() {
		// TODO Auto-generated method stub
		System.out.println("Name: " + name);
		System.out.println("E_ID: " + id);
	}
	abstract void confidentialDetails(double Salary, String Performance);
	

}
