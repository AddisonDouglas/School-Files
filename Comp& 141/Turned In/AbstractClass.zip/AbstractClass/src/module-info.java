/**
 * 
 */
/**
 * @author broke
 *
 */
module AbstractClass {
}