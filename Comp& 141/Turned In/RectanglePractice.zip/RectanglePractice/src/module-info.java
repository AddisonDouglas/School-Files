/**
 * 
 */
/**
 * @author broke
 *
 */
module RectanglePractice {
}