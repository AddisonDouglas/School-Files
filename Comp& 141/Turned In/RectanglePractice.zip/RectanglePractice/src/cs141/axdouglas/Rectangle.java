/**
 * 
 */
package cs141.axdouglas;

/**
 * @author broke
 *
 */
public class Rectangle {
	private double height = 0;
	private double width = 0;
	public Rectangle() {
		this.height = 5;
		this.width = 8;
	}
	public Rectangle(int h, int w) {
		height = h;
		width = w;
		
	}
	public Rectangle(double h, double w) {
		height = (int)h;
		width = (int)w;
		
	}
	public double getPerimeter() {
		return (height *2) + (width *2);
	}
	
	public double getArea() {
		return height * width;
	}
	public double getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public double getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}



}
