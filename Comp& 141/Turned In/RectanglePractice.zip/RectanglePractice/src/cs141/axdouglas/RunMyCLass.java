/**
 * 
 */
package cs141.axdouglas;

/**
 * @author broke
 *
 */
public class RunMyCLass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//No argument constructor sets height to 5 and width to 8
		Rectangle obj1 = new Rectangle();
		Rectangle obj2 = new Rectangle(15, 10);
		Rectangle obj3 = new Rectangle(8.0, 6.0);
		System.out.println("obj1 Area: "+ obj1.getArea());
		System.out.println("obj2 Area: "+ obj2.getArea());
		System.out.println("obj3 Area: "+ obj3.getArea());
		System.out.println("obj1 Perimeter: "+ obj1.getPerimeter());
		System.out.println("obj2 Perimeter: "+obj2.getPerimeter());
		System.out.println("obj3 Perimeter: "+obj3.getPerimeter());
		

	}

}
