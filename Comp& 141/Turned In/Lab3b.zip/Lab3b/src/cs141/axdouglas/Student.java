/**
 * 
 */
package cs141.axdouglas;

import java.util.Scanner;

/**
 * @author axdouglas
 *
 */
public class Student {
	public String firstName;
	public String lastName;
	public int studentId;
	public double grade1, grade2, grade3;
	public static int count; // static variable to track number of student objects made
	//Constructor with no grade input
	public Student(String firstName, String lastName, int studentId) {
		if(studentId < 0) { //stop id from being a negative number
			Scanner input = new Scanner(System.in);
			System.out.println("Invalid id positive only, input correct id");
			int temp = input.nextInt();
			while(temp < 0) {
				System.out.println("Invalid id positive only, input correct id");
				temp = input.nextInt();
			}
			this.studentId = temp;
			input.close();
			
		}
		else {
			this.studentId = studentId;
		}
		this.firstName = firstName;
		this.lastName = lastName;
		this.grade1 = Math.random() * 100;
		this.grade2 = Math.random() * 100;
		this.grade3 = Math.random() * 100;
		count++;
		
	}
	//Constructor with 1 grade input
	public Student(String firstName, String lastName, int studentId, double grade1) {
		if(studentId < 0) { //stop id from being a negative number
			Scanner input = new Scanner(System.in);
			System.out.println("Invalid id positive only, input correct id");
			int temp = input.nextInt();
			while(temp < 0) {
				System.out.println("Invalid id positive only, input correct id");
				temp = input.nextInt();
			}
			this.studentId = temp;
			input.close();
			
		}
		else {
			this.studentId = studentId;
		}
		this.firstName = firstName;
		this.lastName = lastName;
		this.grade1 = grade1;
		this.grade2 = Math.random() * 100;
		this.grade3 = Math.random() * 100;
		count++;
		
		
		
		
	}
	//Constructor with 2 grade input
	public Student(String firstName, String lastName, int studentId, double grade1, double grade2) {
		if(studentId < 0) { //stop id from being a negative number
			Scanner input = new Scanner(System.in);
			System.out.println("Invalid id positive only, input correct id");
			int temp = input.nextInt();
			while(temp < 0) {
				System.out.println("Invalid id positive only, input correct id");
				temp = input.nextInt();
			}
			this.studentId = temp;
			input.close();
			
		}
		else {
			this.studentId = studentId;
		}
		this.firstName = firstName;
		this.lastName = lastName;
		this.grade1 = grade1;
		this.grade2 = grade2;
		this.grade3 = Math.random() * 100;
		count ++;
		
		
	}
	//Constructor with 3 grade input
	public Student(String firstName, String lastName, int studentId, double grade1, double grade2, double grade3) {
		if(studentId < 0) { //stop id from being a negative number
			Scanner input = new Scanner(System.in);
			System.out.println("Invalid id positive only, input correct id");
			int temp = input.nextInt();
			while(temp < 0) {
				System.out.println("Invalid id positive only, input correct id");
				temp = input.nextInt();
			}
			this.studentId = temp;
			input.close();
			
		}
		else {
			this.studentId = studentId;
		}
		this.firstName = firstName;
		this.lastName = lastName;
		this.grade1 = grade1;
		this.grade2 = grade2;
		this.grade3 = grade3;
		count ++;
		
		
	}
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return the studentId
	 */
	public int getStudentId() {
		return studentId;
	}
	/**
	 * @param studentId the studentId to set
	 */
	public void setStudentId(int studentId) {
		if(studentId < 0) { //stop id from being a negative number
			Scanner input = new Scanner(System.in);
			System.out.println("Invalid id positive only, input correct id");
			int temp = input.nextInt();
			while(temp < 0) {
				System.out.println("Invalid id positive only, input correct id");
				temp = input.nextInt();
			}
			this.studentId = temp;
			input.close();
			
		}
		else {
			this.studentId = studentId;
		}
	}
	/**
	 * @return the grade1
	 */
	public double getGrade1() {
		return grade1;
	}
	/**
	 * @param grade1 the grade1 to set
	 */
	public void setGrade1(double grade1) {
		if(grade1 > 100) {
			this.grade1 = 100;
			
		}
		else if(grade1 <= 0)
		{
			this.grade1 = 0;
		}
		else {
			this.grade1 = grade1;
		}
		
	}
	/**
	 * @return the grade2
	 */
	public double getGrade2() {
		return grade2;
	}
	/**
	 * @param grade2 the grade2 to set
	 */
	public void setGrade2(double grade2) {
		if(grade2 > 100) {
			this.grade2 = 100;
			
		}
		else if(grade2 <= 0)
		{
			this.grade2 = 0;
		}
		else {
			this.grade2 = grade2;
		}
		
	}
	
	/**
	 * @return the grade3
	 */
	public double getGrade3() {
		return grade3;
	}
	/**
	 * @param grade3 the grade3 to set
	 */
	public void setGrade3(double grade3) {
		if(grade3 > 100) {
			this.grade3 = 100;
			
		}
		else if(grade3 <= 0)
		{
			this.grade3 = 0;
		}
		else {
			this.grade3 = grade3;
		}
	}
	/**
	 * @return the count
	 */
	public static int getCount() {
		return count;
	}
	public double calculateGPA() {
		return (grade1 + grade2 + grade3) / 3.00;
	}
	
	//Print out info in easy to read manner
	public void printStudentInfo() {
		System.out.println("************************");
		System.out.println("Student name: " + firstName + " " + lastName);
		System.out.println("Student ID: " + this.studentId);
		System.out.printf("Student Grades: %.02f, %.02f, %.02f %n", grade1, grade2 , grade3);
		System.out.printf("Student GPA: %.02f %n", calculateGPA());
	}
	}
	
	


