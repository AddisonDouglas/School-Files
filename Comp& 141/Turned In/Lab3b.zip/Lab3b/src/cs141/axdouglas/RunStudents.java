/**
 * 
 */
package cs141.axdouglas;



/**
 * @author axdouglas
 *
 */
public class RunStudents {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Student Jeff = new Student("Jeff", "Smith", 1);
		Student Jim = new Student("Jim", "Jack", 2, 30);
		Student Mike = new Student("Mike", "Doug", 2, 80, 90);
		Student Joe = new Student("Joe", "Herder", 2, 15, 60, 34);
		Jeff.printStudentInfo();
		Jim.printStudentInfo();
		Mike.printStudentInfo();
		Joe.printStudentInfo();
		System.out.println("Students Created: " + Student.getCount());
		

	}

}
