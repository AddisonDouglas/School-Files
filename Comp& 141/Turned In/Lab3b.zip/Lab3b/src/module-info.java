/**
 * 
 */
/**
 * @author broke
 *
 */
module Lab3b {
}