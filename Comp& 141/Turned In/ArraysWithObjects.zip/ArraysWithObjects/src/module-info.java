/**
 * 
 */
/**
 * @author broke
 *
 */
module ArraysWithObjects {
}