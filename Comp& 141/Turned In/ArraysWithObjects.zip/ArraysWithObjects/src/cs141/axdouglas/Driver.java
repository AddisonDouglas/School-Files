/**
 * 
 */
package cs141.axdouglas;

import java.util.Scanner;

/**
 * @author axdouglas
 *
 */
/**
 * Name:Addison Douglas
 * Section: 2
 * Program Name: Driver
 * Description: This class gets the user input for make and year model 3 times, each time passing that info into
 * a new car object that is created, an Car object array is then created and the three cars are stored in it
 * the array is then used to call the print method for all three car objects
 *
 */
public class Driver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner userInput = new Scanner(System.in);
		Car carArray[] = new Car[3];
		int year;
		String make;
		for(int i = 0; i < carArray.length; i++) {
			System.out.printf("Enter the year model for car #%d: ", i + 1);
			year = userInput.nextInt();
			System.out.printf("Enter make for car #%d: ", i + 1);
			make = userInput.next();
			carArray[i] = new Car(year, make);
		}
		System.out.println("######Printing######");
		System.out.println("There are " + Car.getCarCount() + " cars in the system");
		System.out.println("-----------------------");
		for (int i = 0; i < carArray.length; i++) {
			carArray[i].print();
			System.out.println("-----------------------");
		}
		userInput.close();


	}

}
