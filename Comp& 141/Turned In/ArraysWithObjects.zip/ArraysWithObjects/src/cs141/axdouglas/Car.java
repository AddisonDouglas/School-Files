/**
 * 
 */
package cs141.axdouglas;

/**
 * @author axdouglas
 *
 */
/**
 * Name:Addison Douglas
 * Section: 1
 * Program Name: Car
 * Description: This is the car class it has three variables, a int yearModel, a String make, and a static int carCount
 * the yearModel and make are set by the constructor, the carCount is incremented each time an object is created, 
 *
 */
public class Car {

	private int yearModel;
	private String make;
	static private int carCount;


	public Car(int yearModel, String make) {
		this.yearModel = yearModel;
		this.make = make;
		carCount++;
		
	}
	/**
	 * @return the carCount
	 */
	public static int getCarCount() {
		return carCount;
	}
	/**
	 * @return the yearModel
	 */
	public int getYearModel() {
		return yearModel;
	}
	/**
	 * @param yearModel the yearModel to set
	 */
	public void setYearModel(int yearModel) {
		this.yearModel = yearModel;
	}
	/**
	 * @return the make
	 */
	public String getMake() {
		return make;
	}
	/**
	 * @param make the make to set
	 */
	public void setMake(String make) {
		this.make = make;
	}
	//Prints out the make and yearModel of the car in a easy to understand way
	public void print() {
		System.out.println("The make of the car is: " + make);
		System.out.println("The year model of the car is: " + yearModel);
	}

}
