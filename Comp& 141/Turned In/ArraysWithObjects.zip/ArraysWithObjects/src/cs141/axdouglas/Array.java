/**
 * 
 */
package cs141.axdouglas;

import java.util.Scanner;

/**
 * @author broke
 *
 */
public class Array {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String [] owner = {"Alice", "Bob", "Carol"};
		Scanner userInput = new Scanner(System.in);
		System.out.print("Who are you looking for?");
		String name = userInput.next();
		boolean test = false;
		for (int index = 0; index < owner.length; index++) {
			if(owner[index].equalsIgnoreCase(name)) {
				test = true;
			}
			
		}
		if(test) {
			System.out.println(name + " is in the list");
			
		}
		else {
			System.out.println(name + " is not in the list");
		}
		System.out.println();
		for (int index = 0; index < owner.length; index++) {
			System.out.println(owner[index]);
		}
		userInput.close();	
		}
	

	}


