/**
 * 
 */
/**
 * @author broke
 *
 */
module Lab3A {
}