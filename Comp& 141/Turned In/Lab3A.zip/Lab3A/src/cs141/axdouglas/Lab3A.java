/**
 * 
 */
package cs141.axdouglas;

import java.util.Scanner;

/**
 * @author axdouglas
 *
 */
public class Lab3A {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Lab3A object = new Lab3A();
		
		Scanner userInput = new Scanner(System.in);
		System.out.print("Input the temperature in Kelvin:");
		double input = userInput.nextDouble();
		double fahr = object.kelvinToFahrenheit(input);
		System.out.println("The temperature in Kelvin: " + input);
		System.out.printf("The temperature in Fahrenheit: %.002f%n", fahr);
		
		System.out.print("Input the temperature in Kelvin:");
		input = userInput.nextDouble();
		double cel = object.kelvinToCelsius(input);
		System.out.println("The temperature in Kelvin: " + input);
		System.out.printf("The temperature in Celsius: %.002f%n", cel);
		
		System.out.print("Input the temperature in Fahrenheit:");
		input = userInput.nextDouble();
		double fahr2 = object.fahrenheitTokelvin(input);
		System.out.println("The temperature in Fahrenheit: " + input);
		System.out.printf("The temperature in Kelvin: %.002f%n", fahr2);
		
		System.out.print("Input the temperature in Celsius:");
		input = userInput.nextDouble();
		double cel2 = object.celsiusTokelvin(input);
		System.out.println("The temperature in Celsius: " + input);
		System.out.printf("The temperature in Kelvin: %.002f%n", cel2);

	}
	public double kelvinToFahrenheit(double input) {
		double fahr = (input - 273.15) * 9/5 + 32;
		return fahr;
		
	
	}
	public  double kelvinToCelsius(double input) {
		double cel = input - 273.15;
		return cel;
		
	}
	public  double fahrenheitTokelvin(double input) {
		double fahr2 = (input - 32) * 5/9 + 273.15;
		return fahr2;
	}
	public  double celsiusTokelvin(double input) {
		double cel2 = input + 273.15;
		return cel2;
		
	}
	

}
