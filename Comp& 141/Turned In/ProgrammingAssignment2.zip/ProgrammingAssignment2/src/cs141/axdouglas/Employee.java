/**
 * 
 */
package cs141.axdouglas;

/**
 * @author axdouglas
 *
 */
/**
 * Name:Addison Douglas
 * Section: 2
 * Program Name: Employee
 * Description: This is the employee class, in the construcor it takes in 5 varibles, one for name, gender, jobtitle, organization, 
 * and birthday of the employee, the id is then randomly generted, and totalEmployee is increased, depending
 * on what organizatin the employee is in either microsoftCount or googleCount is inreased, beyond that there are setters
 * and getters for the varibles and a toString method to format the output of the employee class.
 *
 */
public class Employee {

	private int id;
	private String name;
	private String gender;
	private String jobTitle;
	private String Organazation;
	private String birthday;
	static private int microsoftCount;
	static private int googleCount;
	static private int totalEmployee;

	public Employee(String name, String gender, String jobTitle, String organazation, String birthday) {
		totalEmployee++;
		this.name = name;
		this.gender = gender;
		this.jobTitle = jobTitle;
		this.Organazation = organazation;
		this.birthday = birthday;
		if(organazation.equalsIgnoreCase("Microsoft")) {
			microsoftCount++;
		}
		else {
			googleCount++;
		}
		id = (int) (Math.random() * 1000000); 
	}
	public String toString() {
		return ("ID: " + id + "\n" + "Name: " + name + "\n" + "Gender: " + gender + "\n" + "Job title: " + jobTitle + "\n" + "Organiztion: " + Organazation + "\n" + "Birthday: " + birthday);
	}
	/**
	 * @return the totalEmployee
	 */
	public static int getTotalEmployee() {
		return totalEmployee;
	}
	/**
	 * @param totalEmployee the totalEmployee to set
	 */
	public static void setTotalEmployee(int totalEmployee) {
		Employee.totalEmployee = totalEmployee;
	}
	/**
	 * @return the name
	 */
	/**
	 * @return the microsoftCount
	 */
	public static int getMicrosoftCount() {
		return microsoftCount;
	}
	/**
	 * @return the googleCount
	 */
	public static int getGoogleCount() {
		return googleCount;
	}
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}
	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}
	/**
	 * @return the jobTitle
	 */
	public String getJobTitle() {
		return jobTitle;
	}
	/**
	 * @param jobTitle the jobTitle to set
	 */
	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}
	/**
	 * @return the organazation
	 */
	public String getOrganazation() {
		return Organazation;
	}
	/**
	 * @param organazation the organazation to set
	 */
	public void setOrganazation(String organazation) {
		Organazation = organazation;
	}
	
	
	

}
