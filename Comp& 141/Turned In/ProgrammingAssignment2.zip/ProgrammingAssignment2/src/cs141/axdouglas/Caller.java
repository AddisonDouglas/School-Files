/**
 * 
 */
package cs141.axdouglas;

import java.util.Scanner;

/**
 * @author axdouglas
 *
 */
/**
 * Name:Addison Douglas
 * Section: 1
 * Program Name: Caller
 * Description: This is the class to call the employee class
 * It has 2 methods, add employee which takes user input and creates an employee and the printemployee
 * class which prints out all the employees in the allArray, an Array containing all the employess that
 * have been created
 *
 */
public class Caller {
	static Employee allArray[] = new Employee[5];
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner userInput = new Scanner(System.in);
		System.out.println("~~~~Welcome to the Employee Managment System 1.0~~~~");
		Employee Employee1 = addEmployee(userInput);
		System.out.println("~~~~~~~~~~~~~~~~~~~~~");
		Employee Employee2 = addEmployee(userInput);
		System.out.println("~~~~~~~~~~~~~~~~~~~~~");
		Employee Employee3 = addEmployee(userInput);
		System.out.println("~~~~~~~~~~~~~~~~~~~~~");
		allArray[0] = Employee1;
		allArray[1] = Employee2;
		allArray[2] = Employee3;
		printEmployee();

	}
	public static Employee addEmployee(Scanner userInput) {
		boolean test = true;
		int organaztionNumber;
		Scanner userInput2 = new Scanner(System.in);
		String organaztion = "";
		System.out.print("Enter employee name: ");
		String name = userInput.nextLine();
		System.out.print("Enter employee gender: ");
		String gender = userInput.nextLine();
		System.out.print("Enter employee job title: ");
		String jobTitle = userInput.nextLine();
		System.out.print("Enter employee birthday, format mm/dd/yy ");
		String birthday = userInput.nextLine();
		while(test) {
			System.out.print("Please choose an organaztion, type 1 for Google 2 for Mircosoft: ");
			organaztionNumber = userInput2.nextInt();
			if(organaztionNumber == 1){
				organaztion = "Google";
				break;
			}
			else if(organaztionNumber == 2) {
				organaztion = "Microsoft";
				break;
			}
		}
		Employee employee = new Employee(name, gender, jobTitle, organaztion, birthday);
		return employee;
	}
	public static void printEmployee() {
		
		int total = Employee.getTotalEmployee();
		System.out.println("Total employee count: " + Employee.getTotalEmployee() + " ");
		System.out.print("Total google employee count: " + Employee.getGoogleCount()+ " ");
		System.out.print("Total microsoft employee count: " + Employee.getMicrosoftCount()+ " \n");
		for(int i = 0; i < total; i++) {
			System.out.println(allArray[i]);
		}
	}

}
