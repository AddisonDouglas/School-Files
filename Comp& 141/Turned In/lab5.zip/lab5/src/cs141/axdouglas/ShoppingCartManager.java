/**
 * 
 */
package cs141.axdouglas;

import java.util.Scanner;

/**
 * @author axdouglas
 *
 */
/**
 * Name:Addison Douglas
 * Section: 3
 * Program Name: ShoppingCartManager
 * Description: This is the main class which the user interacts with. This class interacts with the ShoppingCart class. Takes in name
 * and date to create a new shopping cart object and then gives the user options of what to d0 they canadd item, remove an item, modify item quantity
 * Display item name and description, Display cart content, and Exit, these options are held in a while loop so the user may keep going untill
 * the choose exit. All the options call back to the ShoppingCart class, which describes what these methods do. 
 *
 */
public class ShoppingCartManager {
	static ShoppingCart cart1;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner userInput = new Scanner(System.in);
		System.out.println("Welcome To shopping Cart manager");
		System.out.print("Please Enter your name: ");
		String name = userInput.next();
		System.out.print("Please Enter the Date: ");
		String date = userInput.next();
		cart1 = new ShoppingCart(name, date);
		System.out.printf("Welcome %s%n", name);
		System.out.printf("%25s%n", "Options");
		boolean test = true;
		while(test){
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			System.out.printf("1.%-15s%n2.%-15s%n3.%-15s%n4.%-15s%n5.%-15s%n6.%-15s%n", "add item", "remove an item", "modify item quantity", "Display item name and description", "Display cart content", "Exit");
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			int input = userInput.nextInt();
			switch (input) {
			case 1: addItem();
					break;
			case 2: removeItem();
					break;
			case 3: setItemQuantity();
					break;
			case 4: displayItemInformation();
					break;
			case 5: cart1.displayCartContents();
					break;
			case 6: test = false;
			}
		}
		System.out.println("Thank you for using shopping cart manager");
		

	}
	public static void addItem() {
		Scanner userInput = new Scanner(System.in); 
		String name;
		String description;
		double price;
		int quantity;
		System.out.print("Provide item name:");
		name = userInput.nextLine();
		System.out.print("Provide item description:");
		description = userInput.nextLine();
		System.out.println("Provide item price:");
		price = userInput.nextDouble();
		System.out.println("Provide item quantity:");
		quantity = userInput.nextInt();
		cart1.addItem(name, description, price, quantity);
	}
	public static void removeItem() {
		Scanner userInput = new Scanner(System.in);
		int index = 0;
		System.out.print("Enter item you wish to remove(using numbers on the side)");
		cart1.displayCartContentsForDiffrentUse();
		index = userInput.nextInt();
		cart1.removeItem(index);
	}
	public static void setItemQuantity() {
		Scanner userInput = new Scanner(System.in);
		int index = 0;
		int newQuantity = 0;
		System.out.println("Enter item you wish to Change quantity for(using numbers on the side)");
		cart1.displayCartContentsForDiffrentUse();
		index = userInput.nextInt();
		System.out.print("What is the new quantity");
		newQuantity = userInput.nextInt();
		cart1.setItemQuantity(index, newQuantity);
		
		
	}
	public static void displayItemInformation() {
		Scanner userInput = new Scanner(System.in);
		int index = 0;
		System.out.println("Enter item you wish to see name and description for(using numbers on the side)");
		cart1.displayCartContentsForDiffrentUse();
		index = userInput.nextInt();
		cart1.displayItemInformation(index);
		
	}
}
