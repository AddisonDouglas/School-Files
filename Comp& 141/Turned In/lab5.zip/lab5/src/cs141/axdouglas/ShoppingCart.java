/**
 * 
 */
package cs141.axdouglas;

import java.util.ArrayList;

/**
 * @author axdouglas
 *
 */
/**
 * Name:Addison Douglas
 * Section: 2
 * Program Name: ShoppingCart
 * Description: The shopping cart class interacts with shoppingcartmanager and item class. It hold an arraylist of Item objects. The construcor accepts
 * a date and name. You have the method addItem, which takes in name, descriotion, price and quanity, and creates a new item object
 * which is then stored in the cart ArrayList. Remove item takes a index and removes the item from cart, setItemQuantity take a index
 * and quanity, then gets the index from cart and call the setQunatity command from Item and passes through the new quanity
 * displayItemInforamtion is very simlair, taking a index and calling a method from itme,displayCartContentsForDiffrentUse and displayCartContents
 * do very simlair things but print out the cart in diffrent formats, displayCartContentsForDiffrentUse is for when there needs to be 
 * numbers next to itmes so the user can choose an index
 *
 */
public class ShoppingCart {
	private String name;
	private String date;
	ArrayList<Item> cart = new ArrayList<Item>();
	public ShoppingCart(String name, String date) {
		this.name = name;
		this.date = date;
	}
	public void addItem(String name, String description, double price, int quantity) {
		// TODO Auto-generated method stub
		cart.add(new Item(name,description,price,quantity)); 
		
	}
	public void removeItem(int index) {
		// TODO Auto-generated method stub
		cart.remove(index - 1);
		
	}
	public void setItemQuantity(int index, int quantity) {
		// TODO Auto-generated method stub
		cart.get(index-1).setQuantity(quantity);
		
	}
	public void displayItemInformation(int index) {
		// TODO Auto-generated method stub
		cart.get(index-1).printItemInformation();
		
	}
	public void displayCartContentsForDiffrentUse() {
		// TODO Auto-generated method stub
		for(int i = 0; i < cart.size(); i++) {
			System.out.println();
			System.out.print(i + 1 + ". ");
			cart.get(i).print();
		}
		
	}
	public void displayCartContents() {
		// TODO Auto-generated method stub
		System.out.println("Your carts content is: ");
		for(Item g : cart) {
			g.print();
		}
		
	}

}
