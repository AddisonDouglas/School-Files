/**
 * 
 */
package cs141.axdouglas;

/**
 * @author axdouglas
 *
 */
/**
 * Name:Addison Douglas
 * Section: 1
 * Program Name: Item
 * Description: item class, takes in name, description, price and quanity in the constructor, has a print method to be printed out 
 * in a format showing quanity, name, and total price, has a set quanity method to change quanity of item being purchased
 * and print item inofrmation to show name, description and price
 *
 */
public class Item {
	private String name;
	private String description;
	private double price;
	private int quantity;

	public Item(String name, String description, double price, int quantity) {
		this.name = name;
		this.description = description;
		this.price = price;
		this.quantity = quantity;
	}
	public void print() {
		System.out.printf("%d %s for %.02f%n", quantity, name, quantity*price);
	}
	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public void printItemInformation() {
		// TODO Auto-generated method stub
		System.out.println("Name: " + name);
		System.out.println("Description: " + description);
		System.out.println("Price: $" + price);
	}
	

}
