/**
 * 
 */
/**
 * @author broke
 *
 */
module lab5 {
}